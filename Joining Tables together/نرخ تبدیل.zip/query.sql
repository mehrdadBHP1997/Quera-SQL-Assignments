SELECT 'cart'AS 'funnel_stage' ,
       FORMAT((SELECT COUNT(distinct USER_ID)
               FROM carts
               INNER JOIN users ON carts.user_id = users.id)/
              (SELECT COUNT(users.ID)
               FROM users),4) AS 'conversion_rate'

UNION

SELECT 'payment'AS 'funnel_stage' ,
       FORMAT((SELECT COUNT(distinct users.id)
               FROM users
                   JOIN carts  ON users.id = carts.user_id
                JOIN payments ON carts.id = payments.cart_id)/
              (SELECT COUNT(users.ID)
               FROM users),4) AS 'conversion_rate';