SELECT students.* FROM students
left JOIN student_courses  on students.id = student_courses.student_id and course_id = "7"
WHERE student_courses.course_id IS NULL;