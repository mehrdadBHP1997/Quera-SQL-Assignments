select *
from (select job_id, squad_id, sum(salary) as salary
      from employees
      group by job_id, squad_id
      order by job_id asc, squad_id asc) as a

union all

select *
from (select job_id, null as squad_id, sum(salary) as salary
from employees
group by job_id
order by job_id asc) as b

union all

select *
from (select null as job_id, squad_id, sum(salary)as salary
from employees
group by squad_id
order by squad_id asc) as c

union all

select *
from (select null as job_id, null as squad_id, sum(salary) as salary
from employees) as d;

