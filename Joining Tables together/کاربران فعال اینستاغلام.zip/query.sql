select distinct users.id as id, users.username as username from users
join likes on users.id = likes.user_id where likes.created_at BETWEEN '2021-10-01' AND '2021-10-30';

