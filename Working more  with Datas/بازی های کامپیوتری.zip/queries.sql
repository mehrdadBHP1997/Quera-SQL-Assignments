-- Section1
    SELECT Name, Year_of_Release, Global_Sales * 1000000 AS Global_Sales
    FROM games
    WHERE Global_Sales > 20
    ORDER BY Year_of_Release DESC, Global_Sales DESC
    LIMIT 10;
-- Section2
    SELECT Publisher
    FROM games
    GROUP BY Publisher
    ORDER BY SUM(Global_Sales) DESC
    LIMIT 1;
-- Section3
    SELECT COALESCE(Genre, 'OTHER')
    FROM games
    ORDER BY Other_Sales DESC
    LIMIT 1;
-- Section4
    SELECT name, year_of_release, other_sales, global_sales
    FROM games
    ORDER BY (IF(year_of_release >= 2000, 1, 0)) DESC, # show results greater than or equal to the  year of release 2000 at first
             (IF(year_of_release >= 2000, global_sales, other_sales)) DESC,
             id;
     
